//
//  ViewController.m
//  DragDropAcitiy
//
//  Created by Saravanan on 27/09/17.
//  Copyright © 2017 Saro. All rights reserved.
//

#import "DragableView.h"
#import "ViewController.h"

@interface ViewController () <DargViewDelegate>

@property (weak, nonatomic) IBOutlet UILabel *lblTimer;
@property (weak, nonatomic) IBOutlet UIView *vwRedPlace;
@property (weak, nonatomic) IBOutlet UIView *vwBluePlace;
@property (weak, nonatomic) IBOutlet UIView *vwGreenPlace;
@property (weak, nonatomic) IBOutlet UIView *vwOrangePlace;
@property (weak, nonatomic) IBOutlet UIView *vwPurplePlace;

@property (weak, nonatomic) IBOutlet DragableView *vwRead;
@property (weak, nonatomic) IBOutlet DragableView *vwBlue;
@property (weak, nonatomic) IBOutlet DragableView *vwGreen;
@property (weak, nonatomic) IBOutlet DragableView *vwOrnage;

@property (weak, nonatomic) IBOutlet DragableView *vwPurple;


@end

@implementation ViewController
NSTimer *twoMinTimer;
UILabel *lbl;
bool isRed;
bool isBlue;
bool isGreen;
bool isOrange;
bool isPurple;

int totalSeconds = 60;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _lblTimer.text = @"";
    
    _vwRead.delegate = self;
    _vwBlue.delegate = self;
    _vwGreen.delegate = self;
    _vwOrnage.delegate = self;
    _vwPurple.delegate = self;
    
    lbl = [[UILabel alloc] init];
    lbl.frame = CGRectMake(0, 70, self.view.frame.size.width, 40);
    lbl.textAlignment = NSTextAlignmentCenter;
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:lbl];
    lbl.text = @"60";

    
    twoMinTimer = [NSTimer scheduledTimerWithTimeInterval:1.0f
                                              target:self
                                            selector:@selector(method)
                                            userInfo:nil
                                             repeats:YES];
    
   
   
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)method{
    totalSeconds--;
    NSString *str = [NSString stringWithFormat:@"%d",totalSeconds];
    lbl.text = str;
    
    if ( totalSeconds == 0 ) {
        [twoMinTimer invalidate];
        UIAlertController *alertController = [UIAlertController  alertControllerWithTitle:@"Alert"  message:@"Times UP. Want see correct answer"  preferredStyle:UIAlertControllerStyleAlert];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            [self dismissViewControllerAnimated:YES completion:nil];
            
            
        }]];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            _vwRead.center = _vwRedPlace.center;
            _vwBlue.center = _vwBluePlace.center;
            _vwGreen.center = _vwGreenPlace.center;
            _vwOrnage.center = _vwOrangePlace.center;
            _vwPurple.center = _vwPurplePlace.center;
            
            [self dismissViewControllerAnimated:YES completion:nil];
            
            
        }]];
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dragEnd:(UIView *)vw{
  
    isRed = NO;
    isBlue = NO;
    isOrange = NO;
    isGreen = NO;
    isPurple = NO;
    
    _vwRedPlace.layer.borderColor = [[UIColor clearColor]CGColor];
    _vwBluePlace.layer.borderColor = [[UIColor clearColor]CGColor];
    _vwGreenPlace.layer.borderColor = [[UIColor clearColor]CGColor];
    _vwOrangePlace.layer.borderColor = [[UIColor clearColor]CGColor];
    _vwPurplePlace.layer.borderColor = [[UIColor clearColor]CGColor];
    
    
        [self checkingView:_vwRead type:1];
        [self checkingView:_vwBlue type:2];
        [self checkingView:_vwGreen type:3];
        [self checkingView:_vwOrnage type:4];
        [self checkingView:_vwPurple type:5];
        
   
    
}

-(void)checkingView : (DragableView *)checkVw type :(int)type{

        if([self checkInner:checkVw typeVw:_vwRedPlace] == YES){
            
            _vwRedPlace.layer.borderWidth = 2.0;
            
            if(type == 1){
                _vwRedPlace.layer.borderColor = [[UIColor greenColor]CGColor];
                isRed = YES;
            }else{
                isRed = NO;
                 _vwRedPlace.layer.borderColor = [[UIColor redColor]CGColor];
            }

        }else if([self checkInner:checkVw typeVw:_vwBluePlace] == YES){
            
            _vwBluePlace.layer.borderWidth = 2.0;
            
             if(type == 2){
                 isBlue = YES;
                 _vwBluePlace.layer.borderColor = [[UIColor greenColor]CGColor];
             }else{
                 isBlue = NO;
                 _vwBluePlace.layer.borderColor = [[UIColor redColor]CGColor];
             }
          
            
        }else if([self checkInner:checkVw typeVw:_vwGreenPlace] == YES){
            
            _vwGreenPlace.layer.borderWidth = 2.0;
            
            if(type == 3){
                isGreen = YES;
                
                _vwGreenPlace.layer.borderColor = [[UIColor greenColor]CGColor];
            }else{
                isGreen = NO;
                _vwGreenPlace.layer.borderColor = [[UIColor redColor]CGColor];
            }
            
            
        }else if([self checkInner:checkVw typeVw:_vwOrangePlace] == YES){
            
            _vwOrangePlace.layer.borderWidth = 2.0;
            
            if(type == 4){
                isOrange = YES;
                _vwOrangePlace.layer.borderColor = [[UIColor greenColor]CGColor];
            }else{
                isOrange = NO;
                _vwOrangePlace.layer.borderColor = [[UIColor redColor]CGColor];
            }
            
            
        }else if([self checkInner:checkVw typeVw:_vwPurplePlace] == YES){
            
            _vwPurplePlace.layer.borderWidth = 2.0;
            
            if(type == 5){
                isPurple = YES;
                _vwPurplePlace.layer.borderColor = [[UIColor greenColor]CGColor];
            }else{
                isPurple = NO;
                _vwPurplePlace.layer.borderColor = [[UIColor redColor]CGColor];
            }
            
            
        }
    
    
    if(isPurple == YES && isBlue == YES && isGreen == YES && isOrange == YES && isPurple == YES){
        
        UIAlertController *alertController = [UIAlertController  alertControllerWithTitle:@"Alert"  message:@"Perfect You are correct"  preferredStyle:UIAlertControllerStyleAlert];
        
        [alertController addAction:[UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            [self dismissViewControllerAnimated:YES completion:nil];
            
            
        }]];
        

        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    
}


-(BOOL)checkInner: (UIView *)vwPointing typeVw :(UIView *)typeVw {
    
    CGPoint vwPoint = vwPointing.frame.origin;
    CGPoint checkVwpoint = typeVw.frame.origin;
    
    if(vwPoint.x >= checkVwpoint.x && vwPoint.y >= checkVwpoint.y && CGRectGetMaxY(vwPointing.frame) <= CGRectGetMaxY(typeVw.frame) && CGRectGetMaxX(vwPointing.frame) <= CGRectGetMaxX(typeVw.frame)){
        return YES;
        
    }
    return NO;
}
@end
