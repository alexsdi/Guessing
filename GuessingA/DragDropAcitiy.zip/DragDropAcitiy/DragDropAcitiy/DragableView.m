//
//  DragableView.m
//  DragDropAcitiy
//
//  Created by Saravanan on 27/09/17.
//  Copyright © 2017 Saro. All rights reserved.
//

#import "DragableView.h"

@implementation DragableView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *aTouch = [touches anyObject];
    CGPoint location = [aTouch locationInView:self];
    CGPoint previousLocation = [aTouch previousLocationInView:self];
    self.frame = CGRectOffset(self.frame, (location.x - previousLocation.x), (location.y - previousLocation.y));
    
    [_delegate dragEnd:self];
    
}



@end
