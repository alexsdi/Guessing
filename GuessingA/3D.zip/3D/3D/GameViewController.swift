//
//  GameViewController.swift
//  3D
//
//  Created by Saravanan on 28/09/17.
//  Copyright © 2017 Saro. All rights reserved.
//

import UIKit
import QuartzCore
import SceneKit

class GameViewController: UIViewController {
    @IBOutlet weak var btnRotate: UIButton!

    @IBOutlet weak var btnHide: UIButton!
    @IBOutlet weak var scnVw: SCNView!
    
    var textNode : SCNNode!
    let txt = SCNText(string: "SARO", extrusionDepth: 0.5)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         textNode = SCNNode(geometry: txt)
        // create a new scene
      //  let scene = SCNScene(named: "art.scnassets/ship.scn")!
        let scene = SCNScene()
        
        // create and add a camera to the scene
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 15)
        
        
        /*
        // create and add a light to the scene
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .omni
        lightNode.position = SCNVector3(x: 0, y: 10, z: 10)
        scene.rootNode.addChildNode(lightNode)
        
        // create and add an ambient light to the scene
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = UIColor.darkGray
        scene.rootNode.addChildNode(ambientLightNode)
        */
        
        // retrieve the ship node
       // let ship = scene.rootNode.childNode(withName: "ship", recursively: true)!
        
        // animate the 3d object
      //  ship.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 2, z: 0, duration: 1)))
        
        // retrieve the SCNView
        let scnView = scnVw
        
        // set the scene to the view
        scnView?.scene = scene
        
        // allows the user to manipulate the camera
        scnView?.allowsCameraControl = true
        
        // show statistics such as fps and timing information
        scnView?.showsStatistics = false
        
        // configure the view
        scnView?.backgroundColor = UIColor.black
        
        // add a tap gesture recognizer
       // let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        //scnView.addGestureRecognizer(tapGesture)
        
        
        guard let pointOfView = scnView?.pointOfView else { return }

        
        txt.font = UIFont.systemFont(ofSize: 4)

        
        textNode.geometry = txt
        
        textNode.scale = SCNVector3Make(0.2, 0.2, 0.2)
        // Axes: (left/right, low/high, close/far)
        textNode.position = SCNVector3Make(0, 5, -15)

        var minVec = SCNVector3Zero
        var maxVec = SCNVector3Zero
        if textNode.__getBoundingBoxMin(&minVec, max: &maxVec) {
            let distance = SCNVector3(
                x: maxVec.x - minVec.x,
                y: maxVec.y - minVec.y,
                z: maxVec.z - minVec.z)
            
            textNode.pivot = SCNMatrix4MakeTranslation(distance.x / 2, distance.y / 2, distance.z / 2)
        }
        
        txt.firstMaterial!.diffuse.contents = UIColor(red: 245/255, green: 216/255, blue: 0, alpha: 1)
        
        txt.firstMaterial!.specular.contents = UIColor.white
        
        
        let horizontalAction = SCNAction.rotate(by: CGFloat(Double(-45).degreesToRadians), around: SCNVector3Make(0, 1, 0), duration: 0.5)
        
        
        //  horizontalAction.timingMode = .easeInEaseOut
        
        //    let reverseHorizontalAction = horizontalAction.reversed()
        
        let verticalAction = SCNAction.rotate(by: CGFloat(Double(-45).degreesToRadians), around: SCNVector3Make(1, 0, 0), duration: 0.1)
        
        // verticalAction.timingMode = .easeInEaseOut
        // let reverseVerticalAction = verticalAction.reversed()
        
        // Create a sequence of animations
        var sequence = SCNAction.sequence([
            horizontalAction, // pan left
            horizontalAction, // center back
            horizontalAction, // pan right
            horizontalAction, // center back
            horizontalAction, // pan down
            horizontalAction, // center back
            horizontalAction, // pan up
            horizontalAction,
            horizontalAction, // center back
            horizontalAction, // pan down
            horizontalAction, // center back
            horizontalAction, // pan up
            horizontalAction]) // center back
        
        // Make the sequence repeat forever
        sequence = SCNAction.repeatForever(sequence)
        textNode.runAction(sequence)
        textNode.isPaused = true
        //textNode.position = SCNVector3Make(pointOfView.position.x, pointOfView.position.y, pointOfView.position.z)
        scnView?.scene?.rootNode.addChildNode(textNode)
        
        
        // Relative rotations on x and y axes
        
       
       
        
       
        
    }
    
    
   
    
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        // retrieve the SCNView
        let scnView = self.view as! SCNView
        
        // check what nodes are tapped
        let p = gestureRecognize.location(in: scnView)
        let hitResults = scnView.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            // retrieved the first clicked object
            let result: AnyObject = hitResults[0]
            
            // get its material
            let material = result.node!.geometry!.firstMaterial!
            
            // highlight it
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            
            // on completion - unhighlight
            SCNTransaction.completionBlock = {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.5
                
                material.emission.contents = UIColor.black
                
                SCNTransaction.commit()
            }
            
            material.emission.contents = UIColor.red
            
            SCNTransaction.commit()
        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

    @IBAction func onRotate(_ sender: UIButton) {
        
        
        if(sender.isSelected == true){
            
             textNode.isPaused = true
            
        }else{

            textNode.isPaused = false
        }
        
        sender.isSelected = !sender.isSelected
        
        
    }
    
   
    
    @IBAction func onShowHide(_ sender: UIButton) {
        
        textNode.isHidden = !textNode.isHidden
    }
    
}


extension Int {
    var degreesToRadians: Double { return Double(self) * .pi / 180 }
}
extension FloatingPoint {
    var degreesToRadians: Self { return self * .pi / 180 }
    var radiansToDegrees: Self { return self * 180 / .pi }
}
